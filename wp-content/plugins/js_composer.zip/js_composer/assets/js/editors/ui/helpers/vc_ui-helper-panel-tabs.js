(function () {
	'use strict';

	window.vc.HelperPanelTabs = {};
})();
