(function () {
	'use strict';
	window.InlineShortcodeView_vc_column_inner = window.InlineShortcodeView_vc_column.extend( {} );
})();
