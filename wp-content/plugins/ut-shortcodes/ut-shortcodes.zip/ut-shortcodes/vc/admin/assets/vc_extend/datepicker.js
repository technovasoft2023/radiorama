/* <![CDATA[ */
!(function($){
	
	"use strict";
        
    $('.ut-datetimepicker').each(function() {
        
        $(this).utdatetimepicker({
            weeks:true,
            format: 'Y/m/d H:i'
        });
        
    });
        
})(window.jQuery);
 /* ]]> */	