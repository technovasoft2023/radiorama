<?php

namespace Image_Processing_Queue;

/**
* Custom exception class for IPQ background processing
*/
class Exception extends \Exception {}